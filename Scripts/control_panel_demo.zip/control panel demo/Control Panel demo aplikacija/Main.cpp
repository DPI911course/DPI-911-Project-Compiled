/*******************************************************
**   Naziv: Control Panel demo aplikacija - primjer   **
**				kreiranja Control Panel appleta       **
**                                                    **
**   Autor: Gordan Kre�i�                             **
**                                                    **
********************************************************/

#include "windows.h"
#include "cpl.h"
#include "resource.h"

/*
	Struktura CPLINFO - svaki (ozbiljniji) razvojni alat trebao bi je imati
	definiranu u svojim zaglavnim datotekama. Ovdje dajemo samo popis clanova
	strukture i njihov opis.

	Prije toga, razjasnimo samo pojmove resurs ("resource") i njegove oznake
	("resource identifier"). Resurs je bilo koji binarni podatak (slika, tekst (string)
	ili, u krajnjem slu�aju, �ak druga exe datoteka) kojeg ubacujemo (linkamo) u na�
	program u neizmjenjenom obliku. Svaki resurs unutar pojedinog modula (exe ili
	dll datoteke) ima svoj broj - oznaku, kojom je jednozna�no odre�en.	Oznaka
	resursa ("resource identifier") je, dakle, obi�na numeri�ka konstanta.
	Mi �emo u ovom programu koristiti samo dvije vrste resursa: ikone i stringove.

	struct CPLINFO {
		int		idIcon;		// oznaka resursa ikone koja predstavlja applet
		int		idName;		// oznaka resursa stringa koji sadr�i naziv appleta
		int		idInfo;		// oznaka resursa stringa koji sadr�i opis appleta
		LONG	lData;		// korisni�ki definiran podatak (ne koristi se u ovom primjeru)
	}; 
*/

#define NUM_APPLETS	3		// konstanta koja sadr�i broj appleta u ovoj biblioteci

HINSTANCE hInstance = NULL;	// varijabla u koju �emo spremiti rukovatelj (handle) ove biblioteke


LONG CALLBACK CPlApplet(HWND hwndCPL, UINT uMsg, LPARAM lParam1, LPARAM lParam2) {

	/* 
		Opis parametara:
	
		hwndCPL		- rukovatelj (handle) Control Panel prozora
		uMsg;		- kod poruke
		lParam1;	- prvi parametar poruke
		lParam2;	- drugi parametar poruke 

	*/

	LPCPLINFO lpCPlInfo;		// varijabla u koju �emo spremiti pointer na CPLINFO strukturu

	int i = 0;					// varijabla u koju �emo spremiti redni broj appleta kojeg
								// trenutno "obra�ujemo"
    
	switch (uMsg) { 
		case CPL_INIT:		// prva poruka, �alje se samo jednom

			// inicijalizacija appleta

			hInstance = GetModuleHandle("BUGCPl.cpl");

			return TRUE;
			
			break;
 
		case CPL_GETCOUNT:	// druga poruka, �alje se samo jednom

			// obavijestimo Control Panel o broju appleta koji su sadr�ani
			// u ovoj biblioteci
			
			return NUM_APPLETS; 
			
			break; 
 
		case CPL_INQUIRE:	// tre�a poruka, �alje se po jednom za svaki applet

			// damo Control Panelu informacije o svakom pojedinom appletu
			// koji je sadr�an u ovoj biblioteci

			i = (int) lParam1;
			lpCPlInfo = (LPCPLINFO) lParam2; 
			
			ZeroMemory(lpCPlInfo, sizeof(CPLINFO));

			switch (i) {
				
				case 0:
					lpCPlInfo->idIcon = IDI_IKONA_APPLETA_1;
					lpCPlInfo->idName = IDS_NAZIV_APPLETA_1;
					lpCPlInfo->idInfo = IDS_OPIS_APPLETA_1;
					break;
				
				case 1:
					lpCPlInfo->idIcon = IDI_IKONA_APPLETA_2;
					lpCPlInfo->idName = IDS_NAZIV_APPLETA_2;
					lpCPlInfo->idInfo = IDS_OPIS_APPLETA_2;
					break;
				
				case 2:
					lpCPlInfo->idIcon = IDI_IKONA_APPLETA_3;
					lpCPlInfo->idName = IDS_NAZIV_APPLETA_3;
					lpCPlInfo->idInfo = IDS_OPIS_APPLETA_3;
					break;
			}
			break; 

		case CPL_DBLCLK:		// korisnik je dva puta za redom kliknuo na ikonu appleta (double click)

			// prika�emo odgovaraju�i prozor s porukom

			char strNazivAppleta[MAX_PATH + 1], strOpisAppleta[MAX_PATH + 1];

			i = (int) lParam1;

			switch (i) {

				case 0:
					LoadString(hInstance, IDS_NAZIV_APPLETA_1, strNazivAppleta, MAX_PATH);
					LoadString(hInstance, IDS_OPIS_APPLETA_1, strOpisAppleta, MAX_PATH);
					break;
				
				case 1:
					LoadString(hInstance, IDS_NAZIV_APPLETA_2, strNazivAppleta, MAX_PATH);
					LoadString(hInstance, IDS_OPIS_APPLETA_2, strOpisAppleta, MAX_PATH);
					break;

				case 2:
					LoadString(hInstance, IDS_NAZIV_APPLETA_3, strNazivAppleta, MAX_PATH);
					LoadString(hInstance, IDS_OPIS_APPLETA_3, strOpisAppleta, MAX_PATH);
					break;
			}

			MessageBox(hwndCPL, strOpisAppleta, strNazivAppleta, MB_OK);
			
			break; 
 
		case CPL_STOP:		// poruka koja se �alje po jednom za svaki applet, prije CPL_EXIT poruke
			break; 
 
		case CPL_EXIT:		// puruka koja se �alje jednom, prije nego biblioteka bude oslobo�ena iz memorije
			break; 
 
		default: 
			break; 
	} 

	return 0; 
}
